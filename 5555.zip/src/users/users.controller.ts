import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Put,
} from '@nestjs/common';
import { UsersService } from './users.service';
import { createUser } from './dto/createUser.dto';

@Controller('/users')
export class UsersController {
  constructor(private readonly userService: UsersService) {}

  @Get(':id')
  getUser(@Param('id') userId: string): object {
    return this.userService.getUser(userId);
  }

  @Post('postUser')
  postUser(@Body() userBody: createUser): object {
    return this.userService.createUser(userBody);
  }

  @Put('putUser')
  putUser(@Body() userBody: createUser): object {
    return this.userService.putUser(userBody);
  }

  @Patch('patchUser')
  patchUser(@Body() userBody: object): object {
    return this.userService.patchUser(userBody);
  }

  @Delete('deleteUser/:id')
  deleteUser(@Param('id') userId: string): object {
    return this.userService.deleteUser(userId);
  }
}
