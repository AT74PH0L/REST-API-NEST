import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/sequelize';
import { Users } from './entities/users.entity';
import { createUser } from './dto/createUser.dto';

@Injectable()
export class UsersService {
  constructor(
    @InjectModel(Users) private readonly userRepository: typeof Users,
  ) {}

  async getUser(userId: string) {
    return await this.userRepository.findOne({ where: { id: userId } });
  }

  createUser = async (userBody: createUser) => {
    return await this.userRepository.create({
      fname: userBody.fname,
      lname: userBody.lname,
      age: userBody.age,
    });
  };

  putUser = async (userBody: createUser) => {
    const user = await this.userRepository.findOne({
      where: { id: userBody.id },
    });
    if (user != null) {
      return await user.update({
        fname: userBody.fname,
        lname: userBody.lname,
        age: userBody.age,
      });
    } else {
      return null;
    }
  };

  patchUser = (userBody: object) => {
    return userBody;
  };

  deleteUser = async (userId: string) => {
    const user = await this.userRepository.findOne({
      where: { id: userId },
    });
    return await user?.destroy();
  };
}
