export class createUser {
  id: string;
  fname: string;
  lname: string;
  age: number;
}
